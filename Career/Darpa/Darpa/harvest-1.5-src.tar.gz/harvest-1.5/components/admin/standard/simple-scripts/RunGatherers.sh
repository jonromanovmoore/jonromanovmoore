#!/bin/sh
#
#  RunGatherers - Starts the gatherd process for a list of Gatherers
#
#  This can be executed from your system startup scritps.  Use something like:
#
#	su harvest -c '/usr/local/harvest/lib/gatherer/RunGatherers'
#
#  NOTE: this is simply a sample script.  It will likely require modification
#  for your local installation.
#

# Set this to your list of gatherers
#
gatherers='gatherer-A gatherer-B gatherer-C'


cd /
umask 002

HARVEST_HOME=/usr/local/harvest
PATH="$HARVEST_HOME/bin:$HARVEST_HOME/lib/gatherer:$HARVEST_HOME/lib:$PATH"
TMPDIR=/tmp

export PATH HARVEST_HOME TMPDIR

for g in $gatherer; do
	if [ -x $HARVEST_HOME/gatherers/$g/RunGatherd ]; then
        	$HARVEST_HOME/gatherers/$g/RunGatherd 
	fi
done

exit 0
