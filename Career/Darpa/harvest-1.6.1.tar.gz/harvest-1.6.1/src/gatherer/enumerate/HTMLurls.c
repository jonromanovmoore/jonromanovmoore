static char rcsid[] = "$Id: HTMLurls.c,v 2.4 2000/01/21 17:37:33 sxw Exp $";
/* 
 *  HTMLurls - Prints all of the URLs from an HTML file.
 *
 *  Uses code from NCSA Mosaic (version 2.2) libhtmlw.
 *
 *  Usage: HTMLurls filename
 *
 *  DEBUG: none
 *  AUTHOR: Harvest derived
 *
 *  Harvest Indexer http://www.tardis.ed.ac.uk/harvest/
 *  ---------------------------------------------------
 *
 *  The Harvest Indexer is a continued development of code developed by
 *  the Harvest Project. Development is carried out by numerous individuals
 *  in the Internet community, and is not officially connected with the
 *  original Harvest Project or its funding sources.
 * 
 *  Please mail harvest@tardis.ed.ac.uk if you are interested in participating
 *  in the development effort.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
/*  ----------------------------------------------------------------------
 *  Copyright (c) 1994, 1995.  All rights reserved.
 *  
 *    The Harvest software was developed by the Internet Research Task
 *    Force Research Group on Resource Discovery (IRTF-RD):
 *  
 *          Mic Bowman of Transarc Corporation.
 *          Peter Danzig of the University of Southern California.
 *          Darren R. Hardy of the University of Colorado at Boulder.
 *          Udi Manber of the University of Arizona.
 *          Michael F. Schwartz of the University of Colorado at Boulder.
 *          Duane Wessels of the University of Colorado at Boulder.
 *  
 *    This copyright notice applies to software in the Harvest
 *    ``src/'' directory only.  Users should consult the individual
 *    copyright notices in the ``components/'' subdirectories for
 *    copyright information about other software bundled with the
 *    Harvest source code distribution.
 *  
 *  TERMS OF USE
 *    
 *    The Harvest software may be used and re-distributed without
 *    charge, provided that the software origin and research team are
 *    cited in any use of the system.  Most commonly this is
 *    accomplished by including a link to the Harvest Home Page
 *    (http://harvest.cs.colorado.edu/) from the query page of any
 *    Broker you deploy, as well as in the query result pages.  These
 *    links are generated automatically by the standard Broker
 *    software distribution.
 *    
 *    The Harvest software is provided ``as is'', without express or
 *    implied warranty, and with no support nor obligation to assist
 *    in its use, correction, modification or enhancement.  We assume
 *    no liability with respect to the infringement of copyrights,
 *    trade secrets, or any patents, and are not responsible for
 *    consequential damages.  Proper use of the Harvest software is
 *    entirely the responsibility of the user.
 *  
 *  DERIVATIVE WORKS
 *  
 *    Users may make derivative works from the Harvest software, subject 
 *    to the following constraints:
 *  
 *      - You must include the above copyright notice and these 
 *        accompanying paragraphs in all forms of derivative works, 
 *        and any documentation and other materials related to such 
 *        distribution and use acknowledge that the software was 
 *        developed at the above institutions.
 *  
 *      - You must notify IRTF-RD regarding your distribution of 
 *        the derivative work.
 *  
 *      - You must clearly notify users that your are distributing 
 *        a modified version and not the original Harvest software.
 *  
 *      - Any derivative product is also subject to these copyright 
 *        and use restrictions.
 *  
 *    Note that the Harvest software is NOT in the public domain.  We
 *    retain copyright, as specified above.
 *  
 *  HISTORY OF FREE SOFTWARE STATUS
 *  
 *    Originally we required sites to license the software in cases
 *    where they were going to build commercial products/services
 *    around Harvest.  In June 1995 we changed this policy.  We now
 *    allow people to use the core Harvest software (the code found in
 *    the Harvest ``src/'' directory) for free.  We made this change
 *    in the interest of encouraging the widest possible deployment of
 *    the technology.  The Harvest software is really a reference
 *    implementation of a set of protocols and formats, some of which
 *    we intend to standardize.  We encourage commercial
 *    re-implementations of code complying to this set of standards.  
 *  
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "HTML.h"
#include "util.h"
#include "url.h"

/* Local Variables */
static int RobotsIndex=1;
static int RobotsFollow=1;

static Buffer *urls = NULL;
static char *base = NULL;

/* Global */
char *Url = NULL;

static void usage()
{
    fprintf(stderr, "Usage: HTMLurls [--base-url url] filename\n");
    exit(1);
}

/*
 *  strstr_icase - Looks for string b in string a.  Case insenstive cmps.
 */
char *strstr_icase(a, b)
     char *a, *b;
{
    int asz = strlen(a), bsz = strlen(b);
    static char *p;

    p = a;
    while (asz >= bsz) {
	if (!strncasecmp(p, b, bsz))
	    return (p);
	p++;
	asz--;
    }
    return (NULL);
}

void process_metarobots(s)
     char *s;
{
    char *p, *q, *tmps, *v;
    int all;

    /* Find the NAME in the META */
    if ((tmps = strstr_icase(s, "name")) == NULL)
      return;

    /* Grab the NAME from the NAME = tag */
    if ((p = strchr(tmps, '=')) == NULL)
      return;
    
    p++;                    /* skip '=' */
    while (isspace(*p) || (*p == '\"'))
      p++;                /* skip space '"'s */
    
    q = xstrdup(p);          /* copy name */
  
    if ((p = strchr(q, '\"')) != NULL)      /* terminate string */
      *p = '\0';
    if ((p = strchr(q, ' ')) != NULL)       /* terminate string */
      *p = '\0';
    /* printf("NAME: %s\n",q); */
    if (strcasecmp("ROBOTS",q)!=0) {        /* check for robots string */
      xfree(q);
      return;
    }
    xfree(q);                               /* finished with that bit */
    
    if ((tmps = strstr_icase(s,"content")) == NULL) /* Find content bit */
      return;

    if ((p = strchr(tmps, '=')) == NULL)    /* Find equals */
      return;

    p++;                                    /* skip '=' */
    while (isspace(*p) || (*p == '\"'))
      p++;                                  /* skip space '"'s */
    
    q = xstrdup(p);                         /* copy name */
    if ((p = strchr(q, '\"')) != NULL)      /* terminate string */
      *p = '\0';

    /* printf("CONTENT: %s\n",q); */

    /* Okay - q should now contain the robots meta tag configuration string
     * This should be comma seperated - but we'll allow them to use spaces
     * just to be nice.
     */
    
    all=0;
    v = strtok(q,", ");
    while (v!=NULL) {
      /* printf("TAG: %s\n",v); */
      if (strcasecmp(v,"all")==0) {
	all=1;
      } else if (strcasecmp(v,"none")==0) {
	RobotsFollow=0;
	RobotsIndex=0;
      } else if (strcasecmp(v,"index")==0) {
	RobotsIndex=1;
      } else if (strcasecmp(v,"noindex")==0) {
	RobotsIndex=0;
      } else if (strcasecmp(v,"follow")==0) {
	RobotsFollow=1;
      } else if (strcasecmp(v,"nofollow")==0) {
	RobotsFollow=0;
      }
      v = strtok(NULL,", ");
    }
    /* All overrides everything else */
    if (all==1) {
      RobotsFollow=1;
      RobotsIndex=1;
    }
    /*
    printf("INDEX: %s\n",RobotsIndex?"Yes":"No");
    printf("FOLLOW: %s\n",RobotsFollow?"Yes":"No");
    */
}

/*
 * process_metapull - extract the URL from the META tag for client pull
 * <META HTTP-EQUIV="REFRESH" CONTENT="<secs>; URL=URL">	Netscape 1.1
 * <META HTTP-EQUIV="REFRESH" CONTENT="<secs>,URI">		W3C, HTML 4.0 (REC-html40-19980424)
 * HS, 20-Oct-1997, 03-May-1998
 */
void process_metapull(s)
     char *s;
{
    char *p, *q, *tmps, *v;

    /* Find the HTTP-EQUIV in the META */
    if ((tmps = strstr_icase(s, "http-equiv")) == NULL)
      return;

    /* Skip over the HTTP-EQUIV from the HTTP-EQUIV = tag */
    if ((p = strchr(tmps, '=')) == NULL)
      return;

    p++;                    /* skip '=' */
    while (isspace(*p) || (*p == '\"'))
      p++;                /* skip space '"'s */

    q = xstrdup(p);          /* copy name */

    if ((p = strchr(q, '\"')) != NULL)      /* terminate string */
      *p = '\0';
    if ((p = strchr(q, ' ')) != NULL)       /* terminate string */
      *p = '\0';
    /* printf("HTTP-EQUIV: %s\n",q); */
    if (strcasecmp("REFRESH",q)!=0) {        /* check for 'REFRESH' */
      xfree(q);
      return;
    }
    xfree(q);                               /* finished with that bit */

    if ((tmps = strstr_icase(s, "content")) == NULL) /* Find content bit */
      return;
    if ((p = strchr(tmps, '=')) == NULL)    /* Find equals */
      return;

    if ((p = strpbrk(p, ",;")) == NULL)     /* There is no URL in this refresh, not interesting */
      return;

    p++;				    /* Skip delimiter, ';' or ',' */
    while (isspace(*p)) p++;                /* skip spaces */

    /* p is now first char of something, it may be 'URL=' or the URL itself */
    q = p;	/* save p for later */

    /* If there is URL=, skip it */
    if (strncasecmp(p, "url", 3) == 0) { /* there is URL */
      q += 3;
      while (isspace(*q)) q++;          /* skip spaces */
      if (*q == '=') { 			/* if there is URL = , skip it */
        q++;                            /* skip '=' */
        while (isspace(*q)) q++;          /* skip spaces */
	p = q;
      } /* else - this is HTML 4.0 conformant (?) refresh with (relative) URL starting with letters 'url' */
    }

    q = xstrdup(p);                         /* copy name */
    if ((p = strchr(q, '\"')) != NULL) {    /* terminate string on '"' */
      *p = '\0';
    } else {
      if ((p = strchr(q, '>')) != NULL)     /* terminate string on '>' */
      *p = '\0';
    }

    /* q should now contain the URL */

    /* Relative URLs are processed by various browsers, so enable them */
    if (base != (char *) NULL) {
      v = q;
      q = url_parse_relative(v, base);
      xfree(v);
    }

    if (q != (char *) NULL) {             /* Just in case... */
      add_buffer(urls, q, strlen(q));     /* Add URL to urls */
      add_buffer(urls, "\n", 1);
      xfree(q);
    }
    return;
}


/*
 *  process_framesrc() - Extracts the URL from the frame src tag.
 *
 *  DFM HACK - deals with:
 *      <FRAME SRC="url">
 *      <FRAME SRC = "url">
 *      <FRAME SRC = " url ">
 */
void process_framesrc(s)
     char *s;
{
    char *p, *q, *tmps, *v;

    /* Find the SRC in the FRAME */
    if ((tmps = strstr_icase(s, "src")) == NULL)
        return;

    /* Grab the URL from the SRC */
    if ((p = strchr(tmps, '=')) != NULL) {
        p++;                    /* skip '=' */
        while (isspace(*p) || (*p == '\"'))
            p++;                /* skip space '"'s */
        q = xstrdup(p);          /* copy URL */
        if ((p = strchr(q, '\"')) != NULL)      /* terminate string */
            *p = '\0';
        if ((p = strchr(q, ' ')) != NULL)       /* terminate string */
            *p = '\0';
        if (base != (char *) NULL) {
            v = q;
            q = url_parse_relative(v, base);
            xfree(v);
        }
        if (q != (char *) NULL) {
            add_buffer(urls, q, strlen(q));     /* Add URL to urls */
            add_buffer(urls, "\n", 1);
            xfree(q);
        }
        return;
    }
}

/*
 *  process_anchor() - Extracts the URL from the anchor href tag.
 *  ALSO DOES SO FROM AREA TAG FOR CLIENT SIDE IMAGE MAPS DFM
 *  Will process these anchors (HREF is case-insenstive):
 *
 *      <A HREF="url">
 *      <A HREF = "url">
 *      <A HREF = " url ">
 *
 */
void process_anchor(s)
     char *s;
{
    char *p, *q, *tmps, *v;

    /* Find the HREF in the anchor */
    if ((tmps = strstr_icase(s, "href")) == NULL)
	return;

    /* Grab the URL from the HREF */
    if ((p = strchr(tmps, '=')) != NULL) {
	p++;			/* skip '=' */
	while (isspace(*p) || (*p == '\"'))
	    p++;		/* skip space '"'s */
	q = xstrdup(p);		/* copy URL */
	while ((p = strchr (q, '\n')) != NULL) {
	  strcpy(p, p+1);
    	}
	if ((p = strchr(q, '\"')) != NULL)	/* terminate string */
	    *p = '\0';
	if ((p = strchr(q, ' ')) != NULL)	/* terminate string */
	    *p = '\0';
	if (base != (char *) NULL) {
	    v = q;
	    q = url_parse_relative(v, base);
	    xfree(v);
	}
	if (q != (char *) NULL) {
	    add_buffer(urls, q, strlen(q));	/* Add URL to urls */
	    add_buffer(urls, "\n", 1);
	    xfree(q);
	}
	return;
    }
}

/*
 *  read_file() - Reads the file fp into memory and returns a pointer to it.
 */
Buffer *read_file(fp)
     FILE *fp;
{
    static Buffer *b;
    char buf[BUFSIZ];
    int nread;

    b = create_buffer(BUFSIZ);

    while ((nread = fread(buf, 1, BUFSIZ, fp)) > 0)
	add_buffer(b, buf, nread);

    return (b);
}

void process_base(buf)
     char *buf;
{
    char *t = NULL;
    char *p = NULL;
    char *q = NULL;

    /* Find the HREF in the anchor */
    if ((t = strstr_icase(buf, "href")) == (char *) NULL)
	return;

    /* Grab the URL from the HREF */
    if ((p = strchr(t, '=')) != NULL) {
	p++;			/* skip '=' */
	while (isspace(*p) || (*p == '\"'))
	    p++;		/* skip space '"'s */
	q = xstrdup(p);		/* copy URL */
	if ((p = strchr(q, '\"')) != NULL)	/* terminate string */
	    *p = '\0';
	if ((p = strchr(q, ' ')) != NULL)	/* terminate string */
	    *p = '\0';
    }
    if (q != (char *) NULL) {
	xfree(base);
	base = xstrdup(q);
    }
}

void process_node(mp)
     struct mark_up *mp;
{
    if ((mp->type == M_BASE) &&
	(mp->start != NULL) && (strlen(mp->start) > 5))
	process_base(mp->start);

    if ((mp->type == M_ANCHOR) &&
	(mp->start != NULL) && (strlen(mp->start) > 5))
	process_anchor(mp->start);

	/*DFM hack for FRAMES*/
    if ((mp->type == M_FRAME) &&
        (mp->start != NULL) && (strlen(mp->start) > 5))
        process_framesrc(mp->start);

        /*DFM hack for AREA (client side Image Map*/
    if ((mp->type == M_AREA) &&
        (mp->start != NULL) && (strlen(mp->start) > 5))
        process_anchor(mp->start);
    
    if ((mp->type == M_META) &&
        (mp->start != NULL) && (strlen(mp->start) > 5)) {
            process_metarobots(mp->start);
            process_metapull(mp->start);	/* HS */
        }
}


static void free_struct_markup(x)
     struct mark_up *x;
{
    if (x->text)
	free(x->text);
    if (x->start)
	free(x->start);
    if (x->end)
	free(x->end);
    free(x);
}

int main(argc, argv)
     int argc;
     char *argv[];
{
    struct mark_up *HTMLParse();
    struct mark_up *mp = NULL;
    struct mark_up *walker = NULL;
    struct mark_up *t = NULL;
    Buffer *b = NULL;
    FILE *fp = NULL;
    FILE *logfp = NULL;

    if (getenv("HARVEST_GATHERER_LOGFILE") != (char *) NULL)
	logfp = fopen(getenv("HARVEST_GATHERER_LOGFILE"), "a+");
    if (logfp == (FILE *) NULL)
	logfp = stderr;

    init_log3("HTMLurls", logfp, stderr);
    debug_init();
    for (argc--, argv++; argc > 0 && **argv == '-'; argc--, argv++) {
	if (!strncmp(*argv, "-D", 2)) {
	    debug_flag(*argv);
	} else if (!strcmp(*argv, "--base-url")) {
	    argc--;
	    argv++;
	    if (argc < 1)
		usage();
	    base = xstrdup(*argv);
	}
    }

    if (argc < 1)
	usage();


    /* Parse the HTML file */
    if ((fp = fopen(*argv, "r")) == NULL) {
	log_errno(*argv);
	exit(1);
    }
    if (getenv("ENUMERATOR_URL"))
	Url = xstrdup(getenv("ENUMERATOR_URL"));
    if (Url == (char *) NULL)
	Url = xstrdup(*argv);

    b = read_file(fp);
    fclose(fp);
    mp = HTMLParse(NULL, b->data);
    free_buffer(b);

    urls = create_buffer(BUFSIZ);

    /* Extract important information from the parsed HTML */
    for (walker = mp; walker != NULL;
	t = walker, walker = walker->next, free_struct_markup(t))
	process_node(walker);

    if (RobotsFollow) fwrite(urls->data, 1, urls->length, stdout);
    free_buffer(urls);
    if (RobotsIndex)
      exit(0);
    else
      exit(99); /* Pick a number, any number */
}
