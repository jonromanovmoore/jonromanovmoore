: # *-*-perl-*-*
    eval 'exec perl -S $0 "$@"'
    if $running_under_some_shell;

# -----------------------------------------------------------------
# hsrlibrary.pl
#
# Author: Mic Bowman
#
# Collection of functions used by most HSR programs.
#
# -----------------------------------------------------------------
require 'configure.pl';

# -----------------------------------------------------------------
# Globals
# -----------------------------------------------------------------
$HSR_Configuration = "hsr.conf";
@HSR_Month = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
	      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");

# -----------------------------------------------------------------
# HSR_Initialize
#
# The hsr configuration file is found by searching the following
# locations:
#	- The first argument of the command line
#       - The HSR_CONFIGURATION variable
#       - The HSR_HOME environment variable (plus hsr.conf)
#       - The current directory (plus hsr.conf)
# -----------------------------------------------------------------
sub HSR_Initialize {
    local($tag);

    undef %Config;

    # Process the configuration file
    if (defined $ENV{"HSR_CONFIGURATION"}) {
	&ReadConfiguration($ENV{"HSR_CONFIGURATION"},*Config);
    } elsif (defined $ENV{"HSR_HOME"}) {
	&ReadConfiguration($ENV{"HSR_HOME"} . "/$HSR_Configuration",*Config);
    } else {
	&ReadConfiguration($HSR_Configuration,*Config);
    }

}

# -----------------------------------------------------------------
# HSR_FileName -- create a file name from the configuration variables
# -----------------------------------------------------------------
sub HSR_FileName
{
    local($cffamily,$cfclass) = @_;
    local($dir,$file);

    if (defined $Config{"$cffamily.$cfclass"}) {
	$file = $Config{"$cffamily.$cfclass"};
	return $file if ($file =~ m@^/.+$@);
    }

    if (defined $Config{"$cffamily.Home"}) {
	$dir = $Config{"$cffamily.Home"};
	$file = "$dir/$file";
    }

    return $file;
}

# -----------------------------------------------------------------
# HSR_ParseSOIF() -- parse a SOIF object from IFILE.
# -----------------------------------------------------------------
sub HSR_ParseSOIF {
    local($ifile);
    $ifile = @_[0];

    return () if (eof($ifile));

    local($template_type) = "UNKNOWN";
    local($url) = "UNKNOWN";
    local(%SOIF);
    undef %SOIF;
    local ($attr, $vsize, $value, $end_value);

    while (<$ifile>) {
	last if (/^\@\S+\s*{\s*\S+\s*$/o);
    }
    if (/^\@(\S+)\s*{\s*(\S+)\s*$/o) {
	$template_type = $1, $url = $2;
	$SOIF{"Type"} = $template_type;
	$SOIF{"Description"} = $url;
    } else {
	return ($template_type, $url, %SOIF);	# done
    }

    while (<$ifile>) {
	if (/^\s*([^{]+){(\d+)}:\t(.*\n)/o) {
	    $attr = $1;
	    $vsize = $2;
	    $value = $3;
	    if (length($value) < $vsize) {
		$nleft = $vsize - length($value);
		$end_value = "";
		$x = read($ifile, $end_value, $nleft);
		die "Cannot read $nleft bytes: $!"
		    if ($x != $nleft);
		$value .= $end_value;
		undef $end_value;
	    }
	    chop ($value) if ($value =~ /\n$/);
	    $SOIF{$attr} = $value;
	    undef $value;
	    undef $end_value;
	    next;
	}
	last if (/^}/o);
    }

    return ($template_type, $url, %SOIF);
}

# -----------------------------------------------------------------
# HSR_ParseDescription
# -----------------------------------------------------------------
sub HSR_ParseDescription {
    local($file) = @_;
    local($url,$type);
    local(%obj);

    $url = "";
    $type = "UNKNOWN";

    open(DFILE,"<$file") ||
	die "Unable to open description file ($file): $!\n";

    while (<DFILE>) {
        last if (m@</HEAD>@);

	if (($key, $val) = m@<META NAME="([^"]+)" +CONTENT="(.*)">@) {
	    $obj{$key} = $val;
	}
    }

    $key = "";
    $val = "";
    while (<DFILE>) {
	if (m@<DT>(\S*)</DT><DD>(\S*)</DD>@) {
	    $key = $1; $val = $2;
	    $obj{$key} = $val if ($key !~ /^\s*$/);
	}
	last if (m@</BODY>@);
    }

    if (defined $obj{"HarvestServerType"}) {
	$type = $obj{"HarvestServerType"};
    } elsif (defined $obj{"Type"}) {
	$type = $obj{"Type"};
    }

    if (defined $obj{"Description-File"}) {
	$url = $obj{"Description-File"};
    }
    close(DFILE);

    return ($type,$url,%obj);
}

# -----------------------------------------------------------------
# HSR_WriteDescription
# -----------------------------------------------------------------
sub HSR_WriteDescription {
    local($output);
    local($file,$type,$url,%obj) = @_;
    local($key);

    system("cp $file $file.old");

    # Create the description file
    $output = "";
    foreach $key (sort keys %obj) {
	next if (!defined $obj{$key});
	$val = $obj{$key};
	$output .= "<DT>$key</DT><DD>$val</DD>\n";
    }

    open(DFILE,">$file") ||
	die "Unable to open description file $file: $!\n";

    print DFILE "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">\n";
    print DFILE "<HTML>\n<HEAD>\n";

    foreach $key (sort keys %obj) {
	next if (!defined $obj{$key});
	$val = $obj{$key};
	print DFILE "<META NAME=\"$key\" CONTENT=\"$val\">\n";
    }

    print DFILE "<TITLE>Description for ", $obj{"Description"}, " Harvest Broker</TITLE>\n";
    print DFILE "</HEAD>\n";
    print DFILE "<BODY>\n";
    print DFILE "<H4>Description for ", $obj{"Description"}, " Harvest Broker</H4>\n";
    print DFILE "<HR>\n";

    print DFILE "$output";
    print DFILE "</BODY>\n</HTML>\n";

    close(DFILE);
    chmod(0644, "$file");
}

# -----------------------------------------------------------------
# HSR_DisplayDescription
# -----------------------------------------------------------------
sub HSR_DisplayDescription {
    local($file) = @_;

    open(DFILE,"<$file") ||
	&CGIError("Unable to open description file $sfile");

    while (<DFILE>) {
	print $_;
    }

    close(DFILE);
}

# -----------------------------------------------------------------
# MakeAttribute() -- make a single attribute
# -----------------------------------------------------------------
sub HSR_MakeAttribute {
    local($k, $v, $a) = @_;
    return "" if (($v =~ /^\s*$/) || ($k =~ /^\s*$/));

    $k = substr($k,9) if ($k =~ /^Gatherer-/) ;
    $k = substr($k,7) if ($k =~ /^Broker-/) ;

    $a = $k . "{" . length($v) . "}:\t" . $v . "\n";
    return $a;
}

# -----------------------------------------------------------------
# HSR_DumpSOIFObjects() -- Dump the contents of the information array
# to the output file.
# -----------------------------------------------------------------
sub HSR_DumpSOIFObjects {
    local($ofile,*info) = @_;
    local($k,$t,$u);

    foreach $k (sort keys %info) {
	($t, $u) = split('&',$k,2);
	next if (! defined $info{$k});
	print $ofile "\@$t { $u\n";
	print $ofile $info{$k};
	print $ofile "}\n";
    }
}

# -----------------------------------------------------------------
# HSR_AddSOIFObject() -- Add an object to the information array.
# -----------------------------------------------------------------
sub HSR_AddSOIFObject {
    local($type,$url,%obj,*info) = @_;
    local($output);

    $output = "";
    foreach $k (sort keys %obj) {
	$output .= &HSR_MakeAttribute($k,$obj{$k});
    }
    $info{join('&',$type,$url)} = $output;
}

# -----------------------------------------------------------------
# HSR_ReadSOIFObjects() -- Read SOIF objects from a file and add them to
# the information structure.
# -----------------------------------------------------------------
sub HSR_ReadSOIFObjects {
    local($ifile,*info) = @_;
    local($output);
    local($stype, $surl, %sobj);

    ($stype, $surl, %sobj) = &HSR_ParseSOIF("$ifile");
    while (defined $stype) {
	&HSR_AddSOIFObject($stype,$surl,%sobj,*info);
    } continue {
	($stype, $surl, %sobj) = &HSR_ParseSOIF("$ifile");
    }
}

# -----------------------------------------------------------------
1
