/* 
 *   index.h -- Swish indexer interface header file
 *
 *   $Id: index.h,v 1.1 1997/10/27 22:47:09 sxw Exp $
 */

#ifndef _PARAMS
#if defined(__STDC__) || defined(__cplusplus) || defined(__STRICT_ANSI__)
#define _PARAMS(ARGS) ARGS
#else				/* Traditional C */
#define _PARAMS(ARGS) ()
#endif				/* __STDC__ */
#endif				/* _PARAMS */

int Swish_IND_Index_Start _PARAMS((void));
int Swish_IND_Index_Flush _PARAMS((void));
int Swish_IND_New_Object _PARAMS((reg_t *));
int Swish_IND_Destroy_Obj _PARAMS((reg_t *));
int Swish_IND_Index_Full _PARAMS((void));
int Swish_IND_Index_Incremental _PARAMS((void));
int Swish_IND_initialize _PARAMS((void));
int Swish_IND_config _PARAMS((char *, char *));
int Swish_IND_do_query _PARAMS((qlist_t *, int, int, time_t));
void Swish_IND_Init_Flags _PARAMS((void));
void Swish_IND_Set_Flags _PARAMS((char *, char *));
