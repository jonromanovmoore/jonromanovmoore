static char rcsid[] = "index.c,v 1.9 1995/01/19 21:49:37 hardy Exp";
/*
 *  index.c -- Skeleton for routines for the Harvest broker's indexer
 */
#include "broker.h"
#include "log.h"
#include "index.h"

/* Global variables */
extern char *DIRpath;
extern char *brk_obj_url;
extern int IndexType;

/* XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX *

                              PUBLIC FUNCTIONS                      

 * XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX */

/* ----------------------------------------------------------------- *
   IND_New_Object -- index a new object
 * ----------------------------------------------------------------- */
int IND_New_Object(entry)
reg_t *entry;
{
}

/* ----------------------------------------------------------------- *
   IND_Index_Full -- builds an index of all of the object files.
 * ----------------------------------------------------------------- */ 
int IND_Index_Full()
{
}

/* ----------------------------------------------------------------- *
   IND_Index_Incremental -- do a full incremental update of the index.
 * ----------------------------------------------------------------- */ 
int IND_Index_Incremental()
{
}

/* ----------------------------------------------------------------- *
   IND_Index_Start -- prepare for indexing a stream of objects.
 * ----------------------------------------------------------------- */
int IND_Index_Start()
{
}

/* ----------------------------------------------------------------- *
   IND_Index_Flush -- finish indexing a stream of objects.
 * ----------------------------------------------------------------- */
int IND_Index_Flush()
{
}

/* ----------------------------------------------------------------- *
   IND_Destroy_Obj -- remove an object from the indexer.
 * ----------------------------------------------------------------- */
int IND_Destroy_Obj(entry)
reg_t *entry;
{
}


/* ----------------------------------------------------------------- *
   IND_initialize -- initialize interface to indexer
 * ----------------------------------------------------------------- */
int IND_initialize()
{
}

/* ----------------------------------------------------------------- *
   IND_Init_Flags -- initialize parser flags
 * ----------------------------------------------------------------- */
void IND_Init_Flags()
{
}

/* ----------------------------------------------------------------- *
   IND_Set_Flags -- set query parser flag
 * ----------------------------------------------------------------- */
void IND_Set_Flags(flag,val)
char *flag;
char *val;
{
}

/* ----------------------------------------------------------------- *
   IND_config -- configure indexer specific variables
 * ----------------------------------------------------------------- */
int IND_config(value,tag)
char *value;
char *tag;
{
}

/* ----------------------------------------------------------------- *
   IND_do_query -- construct a query based upon the query list structure.
 * ----------------------------------------------------------------- */ 
int IND_do_query(ql, rsock, qflag, ptime)
qlist_t *ql;
int rsock;
int qflag;
time_t ptime;
{
}

