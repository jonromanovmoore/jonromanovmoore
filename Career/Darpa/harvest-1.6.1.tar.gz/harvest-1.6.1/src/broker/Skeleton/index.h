/* 
 *   index.h -- Skeleton include file for indexer routines.
 *
 *   index.h,v 1.5 1995/01/20 21:07:39 hardy Exp
 */

#ifndef _PARAMS
#if defined(__STDC__) || defined(__cplusplus) || defined(__STRICT_ANSI__)
#define _PARAMS(ARGS) ARGS
#else				/* Traditional C */
#define _PARAMS(ARGS) ()
#endif				/* __STDC__ */
#endif				/* _PARAMS */

int IND_Index_Start _PARAMS((void));
int IND_Index_Flush _PARAMS((void));
int IND_New_Object _PARAMS((reg_t *));
int IND_Destroy_Obj _PARAMS((reg_t *));
int IND_Index_Full _PARAMS((void));
int IND_Index_Incremental _PARAMS((void));
int IND_initialize _PARAMS((void));
int IND_config _PARAMS((char *, char *));
int IND_do_query _PARAMS((qlist_t *, int, int, time_t));
void IND_Init_Flags _PARAMS((void));
void IND_Set_Flags _PARAMS((char *, char *));
