: # *-*-perl-*-*
    eval 'exec perl -S $0 "$@"'
    if $running_under_some_shell;
#
# This file is used for incremental gatherering, see also http.c.
#

$filename = $ARGV[0];
$templates_name = $ENV{'TMPDIR'} . "/All-Files";
$metastate=0;
$header = "";
$body = "";
$md5 = "";
$output = "";
$kozeile = 0;
if (-e $templates_name) {
   open(INPUT,"<$templates_name");
   while (( $kozeile !=3) && ($_ = <INPUT>)) {
      if (($kozeile == 0) && (s/\@FILE//g) && (s/$filename//g) && (!(s/[.a-zA-Z]+//g))) { $kozeil> e = 1;}
      if ($kozeile == 1) {
	if (s/MD5\{32\}: *\t* *//g) { $md5 = $_; }
	elsif (s/\@FILE \{//g) { $kozeile =3 ; 
	   $body .= "</BODY></HTML>\n";
	   if ($metastate == 1) { $header .= "\">\n"; }
	   }
	elsif (s/url-references\{[0-9]+\} *: *\t* *//g) { 
	   if ($metastate==1) { $header .= "\">\n"; $metastate=0;}
	   $kozeile = 2; 
	   }
	elsif (s/title\{[0-9]*\}: *\t* *//g) {
	   $title = $_; }
	elsif (s/Gatherer-[a-zA-Z]+\{[0-9]+\}//g) { 
           if ($metastate==1) { $header .= "\">\n"; $metastate=0;}
	   }
	elsif (s/Update-Time\{[0-9]+\}//g) { 
	   if ($metastate==1) { $header .= "\">\n"; $metastate=0;}
	   }
	elsif (s/Last-Modification-Time\{[0-9]+\}//g) { 
	   if ($metastate==1) { $header .= "\">\n"; $metastate=0;}
	   }
	elsif (s/Time-to-Live\{[0-9]+\}//g) { 
	   if ($metastate==1) { $header .= "\">\n"; $metastate=0;}
	   }
	elsif (s/Refresh-Rate\{[0-9]+\}//g) { 
	   if ($metastate==1) { $header .= "\">\n"; $metastate=0;}
	   }
	elsif (s/Type\{[0-9]+\}//g) { 
	   if ($metastate==1) { $header .= "\">\n"; $metastate=0;}
           }
	elsif (s/File-Size\{[0-9]+\}//g) { 
	   if ($metastate==1) { $header .= "\">\n"; $metastate=0;}
	   }
	elsif (s/body\{[0-9]+\} *: *\t* *//g) {
	   $metastate = 0;
	   $body .= $_ ;
	   }
	elsif (s/^([a-zA-z.-]*)\{[0-9]+\} *: *\t* */$1" CONTENT="/g) { 
	   if ($metastate==1) { $header .= "\">\n"; }
	   	else { $metastate=1; }
	   $header .= "<META NAME=\"" . $_;
		}
	else { if ($metastate == 0) { $body .= $_; }
		  else { $header .= $_; }
	   }
	}
      if ($kozeile == 2) {	
	if (s/\}$//g) { $body .= "</BODY></HTML>"; $kozeile = 1;}
	   elsif (s/^([a-zA-z.-]*)\{[0-9]+\} *: *\t* */$1" CONTENT="/g) {
		if ($metastate==1) { $header .= "\">\n"; }
			else { $metastate=1; }
		$header .= "<META NAME=\"" . $_;
		$kozeile = 1;
	   }
	   else { $_ =~ s/^mailto.*\n*//g;
		  $_ =~ s/ +/ /g;
		  if (($_ ne "") && ($_ ne " ")) {
		    $body .= "<A HREF=\"";
		    $body .= $_;
		    $body .= "\"></A>\n"; }
	   }
      }
   }
   close(INPUT);
if ($kozeile != 0) {
	$header .= "<META NAME=\"WARNING\" CONTENT=\"" . $md5 . "\">\n</HEAD><BODY>\n";
	$output = "<HTML><HEAD><TITLE> " . $title . "\n</TITLE>";
	$output .= $header . $body;
	$output =~ s/\n *\n/\n/mg;
	$output =~ s/\n">/">/mg;
	$output =~ s/ *\{ */ /g;
	$output =~ s/ *\} */ /g;
	$output =~ s/\n *\n/\n/mg;
	print $output;
	print "\n"; }
   }
