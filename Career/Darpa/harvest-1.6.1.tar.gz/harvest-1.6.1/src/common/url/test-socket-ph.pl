: # *-*-perl-*-*
    eval 'exec perl -S $0 "$@"'
    if $running_under_some_shell;

#
# test-socket-ph.pl,v 1.6 1995/08/24 18:20:13 duane Exp
#
# If this script fails to execute, or does not write the message
# "Perl and socket.ph tests okay." then please invoke this script 
# with debugging.  You should type:
#
#    perl -d test-socket-ph.pl
#    t
#    c
# 

#  Change this variable to your HARVEST_HOME
#
$ENV{'HARVEST_HOME'}= "/usr/local/harvest"
	unless defined($ENV{'HARVEST_HOME'});

unshift(@INC, "$ENV{'HARVEST_HOME'}/lib");

print "HARVEST_HOME=$ENV{'HARVEST_HOME'}\n\n";

foreach $i (@INC) {
	print "Found $i/socket.ph\n" if (-f "$i/socket.ph" );
}

print "\n";

system ("uname -a");
print $], "\n";

require 'socket.ph';	# not sys/socket.ph, we use $HARVEST_HOME/lib/socket.ph

$S = &client_socket ('localhost', 7);		# open TCP socket to echo port
print $S "Perl and socket.ph tests okay.\n";	# send a message
$_ = <$S>;					# read a reply
print STDOUT $_;				# show us the reply
close ($S);					# close the socket
exit 0;						# exit



sub client_socket {
	local ($host, $port) = @_;
	local ($sockaddr) = 'S n a4 x8';
	local ($name, $aliases, $proto) = getprotobyname('tcp');
	local ($connected) = 0;
	
	# Lookup addresses for remote hostname
	#
	local($w,$x,$y,$z,@thataddrs) = gethostbyname($host);
	die("Unknown Host: $host\n") unless (@thataddrs);

	# bind local socket to INADDR_ANY
	#
	local ($thissock) = pack($sockaddr, &AF_INET, 0, "\0\0\0\0");
	die("socket: $!\n") unless
		socket (SOCK, &AF_INET, &SOCK_STREAM, $proto);
	die("bind: $!\n") unless
		bind (SOCK, $thissock);

	# Try all addresses
	#
	foreach $thataddr (@thataddrs) {
		local ($that) = pack($sockaddr, &AF_INET, $port, $thataddr);
		if (connect (SOCK, $that)) {
			$connected = 1;
			last;
		}
	}
	die "$host:$port: $!\n" unless ($connected);

	# Set socket to flush-after-write and return it
	#
	select (SOCK); $| = 1;
	select (STDOUT);
	return (SOCK);
}
