: # *-*-perl-*-*
    eval 'exec perl -S $0 "$@"'
    if $running_under_some_shell;
#
# This file is used for incremental gatherering, see also http.c.
#
$md5 = "LEER";
$filename = $ARGV[0];
if (-e $filename) {
   open(INPUT,"<$filename");
   while ($_ = <INPUT>) {
	if (s/<META NAME=\"WARNING\" CONTENT=\"(.*)\">/$1/) { $md5 = $_; }
   }
   close(INPUT);
}
print $md5 . "\n";
