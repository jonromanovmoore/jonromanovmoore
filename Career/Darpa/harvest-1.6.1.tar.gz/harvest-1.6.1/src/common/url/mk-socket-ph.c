static char rcsid[] = "mk-socket-ph.c,v 1.4 1996/01/17 10:10:17 duane Exp";

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>


int main()
{

	printf("if (!defined &_sys_socket_h) {\n");
	printf("    eval 'sub _sys_socket_h {1;}';\n");
	printf("    eval 'sub SOCK_STREAM {%d;}';\n", SOCK_STREAM);
	printf("    eval 'sub SOCK_DGRAM {%d;}';\n", SOCK_DGRAM);
	printf("    eval 'sub SOCK_RAW {%d;}';\n", SOCK_RAW);
	printf("    eval 'sub AF_UNIX {%d;}';\n", AF_UNIX);
	printf("    eval 'sub AF_INET {%d;}';\n", AF_INET);
	printf("    eval 'sub PF_UNIX {%d;}';\n", PF_UNIX);
	printf("    eval 'sub PF_INET {%d;}';\n", PF_INET);
	printf("}\n");
	printf("1;\n");

	exit(0);

}
