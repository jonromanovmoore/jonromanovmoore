: # *-*-perl-*-*
    eval 'exec perl -S $0 "$@"'
    if $running_under_some_shell;
#
# This file is used for incremental gatherering, see also http.c.
#

$filename = $ARGV[0];
$templates_name = $ENV{'TMPDIR'} . "/All-Files";
#$templates_name = "/home/http/data/harvest/gatherers/test/All1";
$lmt = "";
$md5 = "";
if (-e $templates_name) {
  $kozeile = 0;
  open(INPUT,"<$templates_name");
  while (( $kozeile !=2) && ($_ = <INPUT>)) {
    if (($kozeile == 0) && (s/\@FILE//g) && (s/$filename//g) && !(s/[.a-zA-Z]//g)) {
      $kozeile = 1;}
    if ($kozeile == 1) {
      if (s/^Last-Modification-Time\{[0-9]*\}: *\t* *//g) {
        $lmt = $_;
        $lmt =~ s/ *([0-9]*) *\n.*/$1/g;}
      elsif (s/^MD5\{32\}: *\t* *//g) {
        $md5 = $_;
	$md5 =~ s/ //g; 
	$md5 =~ s/\n//mg;}
      elsif (s/\@FILE//g) { $kozeile = 2; }
      if (($lmt ne "") && ($md5 ne "")) { $kozeile = 2; }	
    }
  }
  close(INPUT);
}
if (($lmt ne "")  && ($md5 ne "")) { print $lmt . " " . $md5; print "\n";}
else { print "0 0" };
