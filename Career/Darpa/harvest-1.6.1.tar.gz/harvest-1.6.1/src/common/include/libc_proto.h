

extern char *perror _PARAMS((char *));
extern char *strerror _PARAMS((int));
extern int fclose _PARAMS((FILE *));
extern int fflush _PARAMS((FILE *));
extern int flock _PARAMS((int, int));
extern int fprintf _PARAMS((FILE *, char *, ...));
extern int printf _PARAMS((char *, ...));
extern int fputs _PARAMS((char *, FILE *));
extern int ungetc _PARAMS((int, FILE *));
extern int fgetc _PARAMS((FILE *));
extern int setbuf _PARAMS((FILE *, char *));
extern int fseek _PARAMS((FILE *, long, int));
extern int getdtablesize _PARAMS((void));
extern int gethostname _PARAMS((char *, int));
extern int putenv _PARAMS((char *));
extern int setsockopt _PARAMS((int, int, int, char *, int));
extern int sscanf _PARAMS((char *, char *, ...));
extern int strftime _PARAMS((char *, int, char *, struct tm *));
extern int system _PARAMS((char *));
extern time_t time _PARAMS((time_t *));
extern int tolower _PARAMS((int));
extern int toupper _PARAMS((int));
extern int isupper _PARAMS((int));
extern int isspace _PARAMS((int));
extern int fwrite _PARAMS((char *, int, int, FILE *));
extern int fread  _PARAMS((char *, int, int, FILE *));
extern void bzero _PARAMS((char *, int));
extern void bcopy _PARAMS((char *, char *, int));
extern int fscanf _PARAMS((FILE *, char *, ...));
extern int symlink _PARAMS((char*, char *));
extern int socket _PARAMS((int, int, int));
extern int listen _PARAMS((int, int));
extern int ioctl _PARAMS((int, int, caddr_t));
extern int close _PARAMS((int));
extern int usleep _PARAMS((unsigned int));

#if defined(HAVE_SRAND48)
extern void srand48 _PARAMS((long));
#endif
#if defined(HAVE_LRAND48)
extern long lrand48 _PARAMS((void));
#endif

#if defined(SOCK_STREAM)
extern int connect _PARAMS((int, struct sockaddr *, int));
extern int getsockname _PARAMS((int, struct sockaddr *, int *));
extern int bind _PARAMS((int, struct sockaddr *, int));
extern int accept _PARAMS((int, struct sockaddr *, int *));
#endif

#if defined(HAVE_SETRLIMIT) && defined(RUSAGE_SELF)
extern int setrlimit _PARAMS((int, struct rlimit *));
#endif

#if defined(_HARVEST_SUNOS_)
extern int strcasecmp _PARAMS((char *, char *));
extern int strncasecmp _PARAMS((char *, char *, int));
#endif

#if defined(_HARVEST_SUNOS_) && defined(S_IFREG)
extern int lstat _PARAMS((char *, struct stat *));
#endif
