#!/bin/sh
WP2XDIR="${HARVEST_HOME}/lib/gatherer/wp2x-lib"; export WP2XDIR;
exec wp2x $*
