/*
 * Define structures to hold extended character set translations
 * 
 */

extern char *isolatin1_chars[9][256];
