#!/usr/local/bin/perl

# things this script does:
#    1. removes consecutive <p>'s

$sawp=0;
$sawnonp=0;

while(<>) {
    if($ARGV ne $oldargv) {
	rename($ARGV, $ARGV . '.2.bak');
	open(ARGVOUT, ">$ARGV");
	select(ARGVOUT);
	$oldargv = $ARGV;
    }

    chop;

    if(/^\<[pP]\>$/) {
	if(!$sawp) {
	    print "<p>\n";
	}
        $sawp=1;
    }
    else {
	$sawp=0;
	print "$_\n";
    }

}


    
    
