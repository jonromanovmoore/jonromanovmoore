/*
 * (c) Copyright 1992, 1993 by Panagiotis Tsirigotis
 * All rights reserved.  The file named COPYRIGHT specifies the terms 
 * and conditions for redistribution.
 */


#ifndef SS_SBM_H
#define SS_SBM_H

/*
 * ss_sbm.h,v 1.1.1.1 1994/04/26 19:08:12 hardy Exp
 */

typedef int last_int ;			/* must be signed */

struct sbm_header
{
	last_int *last_occurrence ;
} ;

#endif	/* SS_SBM_H */

