
/*
 * (c) Copyright 1993 by Panagiotis Tsirigotis
 * All rights reserved.  The file named COPYRIGHT specifies the terms 
 * and conditions for redistribution.
 */

#include "options.h"

/*
 * options.c,v 1.2 1994/05/12 18:44:58 hardy Exp
 */

#define NULL         0

void exit();

int e_option;
int l_option;
int v_option;
int n_option;
int d_option;
int p_option;
char *p_option_arg_1;

char *program_name;

int opt_recognize(argc, argv)
int argc;
char *argv[];
{
	int arg;
	char *strrchr();

	program_name = strrchr(argv[0], '/');
	program_name = (program_name == NULL) ? argv[0] : program_name + 1;

	for (arg = 1; arg < argc; arg++)
		if (argv[arg][0] == '-') {
			if (strcmp(&argv[arg][1], "l") == 0)
				l_option = 1;
			else if (strcmp(&argv[arg][1], "v") == 0)
				v_option = 1;
			else if (strcmp(&argv[arg][1], "n") == 0)
				n_option = 1;
			else if (strcmp(&argv[arg][1], "d") == 0)
				d_option = 1;
			else if (strcmp(&argv[arg][1], "e") == 0)
				e_option = 1;
			else if (strcmp(&argv[arg][1], "p") == 0) {
				if (++arg == argc)
					usage();
				p_option_arg_1 = (argv[arg]);
				p_option = 1;
			} else
				usage();
		} else
			break;


	return (arg);
}

void usage()
{
	Sprint(2, "Usage: %s [-l] [-v] [-n] [-d] [-e] [-p process] file\n", program_name);
	exit(1);
}
