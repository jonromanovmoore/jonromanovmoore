/*
 * (c) Copyright 1992, 1993 by Panagiotis Tsirigotis
 * All rights reserved.  The file named COPYRIGHT specifies the terms 
 * and conditions for redistribution.
 */

#ifndef SS_BMH_H
#define SS_BMH_H

/*
 * ss_bmh.h,v 1.1.1.1 1994/04/26 19:08:11 hardy Exp
 */

typedef unsigned shift_int ;

struct bmh_header
{
	shift_int *shift ;
} ;

#endif	/* SS_BMH_H */

