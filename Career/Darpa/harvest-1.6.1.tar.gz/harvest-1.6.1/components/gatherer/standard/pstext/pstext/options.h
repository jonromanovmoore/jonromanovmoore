
/*
 * (c) Copyright 1993 by Panagiotis Tsirigotis
 * All rights reserved.  The file named COPYRIGHT specifies the terms 
 * and conditions for redistribution.
 */

extern int e_option;
extern int l_option;
extern int v_option;
extern int n_option;
extern int d_option;
extern int p_option;
extern char *p_option_arg_1;

#define p_option_arg                   p_option_arg_1

extern char *program_name;

void usage();
