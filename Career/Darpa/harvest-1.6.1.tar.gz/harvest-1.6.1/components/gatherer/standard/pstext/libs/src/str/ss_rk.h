/*
 * (c) Copyright 1992, 1993 by Panagiotis Tsirigotis
 * All rights reserved.  The file named COPYRIGHT specifies the terms 
 * and conditions for redistribution.
 */

#ifndef SS_RK_H
#define SS_RK_H

/*
 * ss_rk.h,v 1.1.1.1 1994/04/26 19:08:11 hardy Exp
 */

#ifndef WIDE_INT
#define WIDE_INT						long
#define WIDE_INT_SIZE				32			/* bits */
#endif

typedef unsigned WIDE_INT wide_int ;

struct rk_header
{
	wide_int rk_digit1 ;				/* in the appropriate radix */
	wide_int rk_patval ;
} ;

#if WIDE_INT_SIZE == 32
#	define PRIME						16777213
#else
#	if WIDE_INT_SIZE == 16
#		define PRIME					251
#	else
		int WIDE_INT_SIZE_has_bad_value = or_is_undefined ;
#	endif 
#endif

#endif	/* SS_RK_H */

