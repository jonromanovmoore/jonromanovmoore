
/*
 * (c) Copyright 1993 by Panagiotis Tsirigotis
 * All rights reserved.  The file named COPYRIGHT specifies the terms 
 * and conditions for redistribution.
 */

static char RCSid[] = "wp.c,v 1.2 1994/05/12 18:45:02 hardy Exp";

#include "sio.h"

#include "defs.h"

void wordperfect_process(fd)
int fd;
{
	char *line;
	int output_string = FALSE;
	void decode_string();
	int get_line_char();

	while (line = Srdline(fd)) {
		char *p;

		if (line[0] == '%')
			continue;

		for (p = line; *p;) {
			if (*p == OPEN_PAREN) {
				if (p > line && p[-1] == CARRIAGE_RETURN)
					printout(SPACE);
				p++;
				decode_string(get_line_char, (void *) &p);
				output_string = TRUE;
			} else if (isdigit(*p)) {
				while (isdigit(*p))
					p++;
				if (isspace(*p)) {
					while (isspace(*p))
						p++;
					if (isdigit(*p)) {
						while (isdigit(*p))
							p++;
						if (output_string) {
							printout(NEWLINE);
							output_string = FALSE;
						}
					}
				}
			} else
				p++;
		}
	}
}
