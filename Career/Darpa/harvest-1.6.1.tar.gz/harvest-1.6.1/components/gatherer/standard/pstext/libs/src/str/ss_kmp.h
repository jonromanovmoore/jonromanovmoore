/*
 * (c) Copyright 1992, 1993 by Panagiotis Tsirigotis
 * All rights reserved.  The file named COPYRIGHT specifies the terms 
 * and conditions for redistribution.
 */

#ifndef SS_KMP_H
#define SS_KMP_H

/*
 * ss_kmp.h,v 1.1.1.1 1994/04/26 19:08:11 hardy Exp
 */

typedef int next_int ;			/* must be signed */

struct kmp_header
{
	next_int *next ;
} ;

#endif	/* SS_KMP_H */

