set ts=3
