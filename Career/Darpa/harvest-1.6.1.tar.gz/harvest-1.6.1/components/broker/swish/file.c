/*
** Copyright (C) 1995, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 3/11/94
**
** Released under the GPL by EIT in October 1997
**
** Heavily modified for Harvest by Simon Wilkinson
*/

#include "swish.h"
#include "file.h"
#include "mem.h"
#include "string.h"

/* Is a file a directory?
*/

int isdirectory(path)
     char *path;
{
        struct stat stbuf;

        if (stat(path, &stbuf))
                return 0;
        return ((stbuf.st_mode & S_IFMT) == S_IFDIR) ? 1 : 0;
}

/* Is a file a regular file?
*/

int isfile(path)
     char *path;
{
        struct stat stbuf;

        if (stat(path, &stbuf))
                return 0;
        return ((stbuf.st_mode & S_IFMT) == S_IFREG) ? 1 : 0;
}

/* Get the size, in bytes, of a file.
** Return -1 if there's a problem.
*/

int getsize(path)
     char *path;
{
        struct stat stbuf;

        if (stat(path, &stbuf))
                return -1;
        return stbuf.st_size;
}

/* Add an entry to the metaEntryList with the given value and the
** appropriate index
*/

struct metaEntry* addMetaEntry(metaList, metaWord)
     struct metaEntry* metaList;
     char* metaWord;
{
  static int counter;
  int i;
  struct metaEntry* newEntry;
  struct metaEntry* tmpEntry;

  if (counter == 0)
    counter = 2;
  else if (counter == 1 ||  (!counter % 128) )
    counter++;
  for( i=0; metaWord[i]; i++)
    metaWord[i] =  tolower(metaWord[i]);
  newEntry = (struct metaEntry*) emalloc(sizeof(struct metaEntry));
  newEntry->metaName = (char*)mystrdup(metaWord);
  newEntry->index = counter++;
  newEntry->next = NULL;
  if (metaEntryList)
    {
      for(tmpEntry=metaEntryList;tmpEntry->next!=NULL;tmpEntry=tmpEntry->next)
	;
      tmpEntry->next = newEntry;
    }
  else
    metaEntryList = newEntry;

  return metaEntryList;
}
