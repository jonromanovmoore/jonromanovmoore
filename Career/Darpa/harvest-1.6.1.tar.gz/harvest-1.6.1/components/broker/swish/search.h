/*
** Copyright (C) 1995, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 3/11/94
**
** Added getMetaName & isMetaName 
** to support METADATA
** G. Hill 3/18/97 ghill@library.berkeley.edu
*/

void search();
struct swline *fixnot();
struct swline *expandstar();
char *getmatchword();
void getheader();
void readoffsets();
void readstopwords();
void readfileoffsets();
void readMetaNames();
int getMetaName();

struct result *parseterm();
struct result *operate();
char *lookupfile();
struct result *getfileinfo();

int isrule();
int isbooleanrule();
int isunaryrule();
int isMetaName();
int getrulenum();

struct result *andresultlists();
struct result *orresultlists();
struct result *notresultlist();
struct result *addtoresultlist();

struct sortresult *addsortresult();
void printsortedresults();

void getrawindexline();
int isokindexheader();
