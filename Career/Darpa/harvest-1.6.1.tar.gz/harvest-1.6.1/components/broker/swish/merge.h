/*
** Copyright (C) 1995, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 3/11/94
**
** Added remapVar and initmapentrylist to fix the merge option -M
** G. Hill 3/7/97
**
*/

struct indexentry {
        char *word;
        struct resultMerge *result;
};

struct resultMerge{
        int filenum;
	int rank;
	int attribute;
	struct resultMerge *next;
};

struct indexfileinfo {
        int filenum;
        char *fileinfo;
	char *path;
        struct indexfileinfo *next;
};

struct mapentry {
	int oldnum;
	int newnum;
	struct mapentry *next;
};

struct markentry {
	int num;
	struct markentry *next;
};

struct markentryMerge {
        int num;
	int attribute;
	struct markentryMerge *next;
};	

struct metaMergeEntry {
  char* metaName;
  int oldIndex;
  int newIndex;
  struct metaMergeEntry* next;
};

struct indexfileinfo *indexfilehashlist[BIGHASHSIZE];
struct mapentry *mapentrylist[BIGHASHSIZE];
struct markentry *markentrylist[BIGHASHSIZE];
struct markentryMerge *markentrylistMerge[BIGHASHSIZE];
int remapVar;

void readmerge();
int getindexfilenum();
void addfilenums();
struct indexentry *readindexline();
void addindexfilelist();
char *extractpath();
char *lookupindexfilenum();
int lookupindexfilepath();
struct indexentry *mergeindexentries();
void printindexentry();
void remap();
int getmap();
void marknum();
void marknumMerge();
int ismarked();
int ismarkedMerge();
void initmarkentrylist();
void initmarkentrylistMerge();
void initindexfilehashlist();
void freeindexentry();
int encodefilenum();
int decodefilenum();
void initmapentrylist();
struct resultMerge *addtoresultlistMerge();
struct metaMergeEntry* readMergeMeta();
struct metaMergeEntry* addMetaMerge();
struct metaEntry* createMetaMerge();
struct metaEntry* addMetaMergeList();


