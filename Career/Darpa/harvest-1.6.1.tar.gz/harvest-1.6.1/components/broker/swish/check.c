/*
** Copyright (C) 1995, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 3/11/94
**
** This file was released under the GPL by EIT in October 1997
**
** Heavily modified for Harvest by Simon Wilkinson (sxw@tardis.ed.ac.uk)
*/

#include "swish.h"
#include "check.h"
#include "hash.h"

/* Should a word be indexed? Consults the stopword hash list
** and checks if the word is of a reasonable length...
** If you have any good rules that can work with most languages,
** please let me know...
*/

int isokword(char *word)
{
        int i, same, hasnumber, hasvowel, hascons,
		numberrow, vowelrow, consrow;
	char lastchar;

	if (word[0] == '\0') return 0;

        if (isstopword(word)) return 0;
        if (strlen(word) < MINWORDLIMIT || strlen(word) > MAXWORDLIMIT)
                return 0;

	return 1;
}

/* Does a word have valid characters?
*/

int hasokchars(char *word)
{
	int i, j;
	char c;

	c = word[strlen(word) - 1];
	for (i = j = 0; BEGINCHARS[i] != '\0'; i++)
		if (word[0] == BEGINCHARS[i])
			j++;
	if (!j)
		return 0;
	for (i = j = 0; ENDCHARS[i] != '\0'; i++)
		if (c == ENDCHARS[i])
			j++;
	if (!j)
		return 0;
	for (i = 0; word[i] != '\0'; i++)
		for (j = 0; WORDCHARS[j] != '\0'; j++)
			if (word[i] == WORDCHARS[j])
				return 1;
	return 0;
}

/* Is a letter a vowel?
*/

int isvowel(char c)
{
	if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
		return 1;
	return 0;
}

