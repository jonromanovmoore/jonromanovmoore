/*
** Copyright (C) 1995, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 3/11/94
*/

char *lstrstr(char *, char *);
char *getword(char *, int *);
char *getconfvalue(char *, char *, char *);
char *mystrdup(char *);
int iswordchar(char);
char *replace(char *, char *, char *);
int wordcompare(char *, char *);
char *convertentities(char *);
char *getent(char *, int *);
char *converttonamed(char *);
int hasnumbered(char *);
char *converttoascii(char *);
int hasnonascii(char *);
