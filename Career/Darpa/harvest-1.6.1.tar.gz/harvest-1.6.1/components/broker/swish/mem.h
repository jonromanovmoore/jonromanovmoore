/*
** Copyright (C) 1995, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 3/11/94
**
** Release under the GPL by EIT
**
** Modified for Harvest
*/

void *emalloc(int);
void *erealloc(void *,int);
