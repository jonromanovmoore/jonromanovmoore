/*
** Copyright (C) 1995, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 3/11/94
** 
** Released under the GPL by EIT
**
** Heavily modified for use in Harvest
*/


int isdirectory();
int isfile();

int getsize();
void getdefaults();
struct metaEntry* addMetaEntry();

