/*
** Copyright (C) 1995, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 3/11/94
**
** Released under the GPL by EIT in October 1997.
**
** Heavily modified for Harvest
*/

int isokword(char *);
int isvowel(char);
int hasokchars(char *);

