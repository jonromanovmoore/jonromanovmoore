define(['jquery','bootstrap'],function($){var didScroll;var lastScrollTop=0;var delta=5;var interval=null;var navClosed=true;var headerHeight=$('.main-header').outerHeight()+$('.nav-subnav').outerHeight();if(headerHeight<100){headerHeight=100;}
function closeDropdowns(){var iOS=/iPad|iPhone|iPod/.test(navigator.userAgent)&&!window.MSStream;if(iOS==false){$('.nav-sticky .dropdown.open .dropdown-toggle').dropdown('toggle');}}
function closeNav(){if(navClosed===false){$('.nav-sticky .navbar').removeClass('nav-down').addClass('nav-up');closeDropdowns();navClosed=true;}}
$(window).scroll(function(event){didScroll=true;runInterval();});function runInterval(){interval=setInterval(function(){if(didScroll){hasScrolled();didScroll=false;}},250)};function hasScrolled(){var st=$(this).scrollTop();if(Math.abs(lastScrollTop-st)<=delta)
return;if(st>lastScrollTop){closeNav();}else{closeDropdowns();if(st+$(window).height()<$(document).height()){$('.nav-sticky .navbar').removeClass('nav-up').addClass('nav-down');navClosed=false;}
if(st<headerHeight){closeNav();}}
lastScrollTop=st;}
$('.nav-sticky .section-nav .dropdown').on('show.bs.dropdown',function(){$('.section-nav i').removeClass('bt-angle-right').addClass('bt-angle-down');});$('.nav-sticky .section-nav .dropdown').on('hide.bs.dropdown',function(){$('.section-nav i').removeClass('bt-angle-down').addClass('bt-angle-right');});});